How to install bcm2835 drivers
1 - Enter into bcm2835 directory
2 - tar zxvf bcm2835-1.37.tar.gz
3 - cd bcm2835-1.37
4 - ./configure
5 - make
6 - sudo make check				// test should pass
7 - sudo make install
