#ifndef APP_MAIN_H
#define APP_MAIN_H

#include <stdint.h>

#define LEDG 				RPI_V2_GPIO_P1_13
#define LEDR 				RPI_V2_GPIO_P1_15
#define SPI_CLOCK_DIVIDER_26	26

#endif /* APP_MAIN_H */
